import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SwingConstants;

public class quote {

	private JFrame frmBuautifulQuotes;
	public JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					quote window = new quote();
					window.frmBuautifulQuotes.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public quote() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	functions f = new functions();
	
	private void initialize() {
		frmBuautifulQuotes = new JFrame();
		frmBuautifulQuotes.setTitle("Buautiful Quotes  by devcyber | version 1.0 ");
		frmBuautifulQuotes.getContentPane().setBackground(Color.YELLOW);
		frmBuautifulQuotes.setBounds(100, 100, 450, 300);
		frmBuautifulQuotes.setResizable(false);
		frmBuautifulQuotes.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmBuautifulQuotes.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to Beautiful Zone");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(25, 32, 386, 156);
		frmBuautifulQuotes.getContentPane().add(lblNewLabel);
		
		
		JButton btnOk = new JButton("OK");
		btnOk.setForeground(Color.YELLOW);
		btnOk.setBackground(Color.BLACK);
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				lblNewLabel.setText("<html><center>"+f.write()+"</center></html>");
				
			}
		});
		btnOk.setBounds(156, 218, 117, 25);
		frmBuautifulQuotes.getContentPane().add(btnOk);
	}
}
