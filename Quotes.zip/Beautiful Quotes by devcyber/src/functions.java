import java.util.Random;
public class functions {
	
	public static String write() {
		Random rnd = new Random();
		String quotes[] = {"“Don't cry because it's over, smile because it happened.” \n" + 
				"― Dr. Seuss",
				"“I'm selfish, impatient and a little insecure. I make mistakes, I am out of control and at times hard to handle. But if you can't handle me at my worst, then you sure as hell don't deserve me at my best.” \n" + 
				"― Marilyn Monroe",
				"“Be yourself; everyone else is already taken.” \n" + 
				"― Oscar Wilde",
				"“Two things are infinite: the universe and human stupidity; and I'm not sure about the universe.” \n" + 
				"― Albert Einstein",
				"“So many books, so little time.” \n" + 
				"― Frank Zappa",
				"“Be who you are and say what you feel, because those who mind don't matter, and those who matter don't mind.” \n" + 
				"― Bernard M. Baruch",
				"“You've gotta dance like there's nobody watching,\n" + 
				"Love like you'll never be hurt,\n" + 
				"Sing like there's nobody listening,\n" + 
				"And live like it's heaven on earth.” \n" + 
				"― William W. Purkey",
				"“A room without books is like a body without a soul.” \n" + 
				"― Marcus Tullius Cicero",
				"“You know you're in love when you can't fall asleep because reality is finally better than your dreams.” \n" + 
				"― Dr. Seuss",
				"“You only live once, but if you do it right, once is enough.” \n" + 
				"― Mae West",
				"“Be the change that you wish to see in the world.” \n" + 
				"― Mahatma Gandhi",
				"“In three words I can sum up everything I've learned about life: it goes on.” \n" + 
				"― Robert Frost",
				"\n" + 
				"“If you want to know what a man's like, take a good look at how he treats his inferiors, not his equals.” \n" + 
				"― J.K. Rowling, Harry Potter and the Goblet of Fire",
				"“Friendship ... is born at the moment when one man says to another \"What! You too? I thought that no one but myself . . .” \n" + 
				"― C.S. Lewis, The Four Loves",
				"“Don’t walk in front of me… I may not follow\n" + 
				"Don’t walk behind me… I may not lead\n" + 
				"Walk beside me… just be my friend” \n" + 
				"― Albert Camus",
				"“No one can make you feel inferior without your consent.” \n" + 
				"― Eleanor Roosevelt, This is My Story",
				"“If you tell the truth, you don't have to remember anything.” \n" + 
				"― Mark Twain",};
		String rq = quotes[rnd.nextInt(quotes.length)];
		//System.out.println(quotes[rnd.nextInt(quotes.length)]);
		return rq;
		
	}
}
